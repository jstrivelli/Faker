VERSION = '0.9.0'

from faker.generator import Generator
from faker.factory import Factory

Faker = Factory.create
